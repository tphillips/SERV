
namespace SERVWeb
{
	using System;
	using System.Web;
	using System.Web.UI;

	public partial class Panels : System.Web.UI.UserControl
	{
	}
}

